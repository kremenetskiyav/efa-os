# W01 EFA All-SKU Current Search Position Audit V1

**Дата аудита:** 2026-09-11  
**Режим:** `READ ONLY`  
**External write:** `NONE`  
**Статус:** `PARTIAL / BROWSER_ACCESS_BLOCKED`  
**SKU scope:** ЭФА УФ 001Б–005Б  

## Executive Summary

- **FACT:** текущая публичная выдача подтверждена сегодняшним W01-снимком только для Москвы и первых восьми результатов по 10 ранее утверждённым OEM-запросам. ЭФА занимает: УФ 001Б — `2`; УФ 003Б — `5` по `97133F2000`; УФ 004Б — `8` по `5Q0819653` и `6` по `5Q0819669`; УФ 005Б — `5` по `647975` и `8` по `647941`. УФ 002Б не найден в первых восьми по обоим запросам. Это не доказывает отсутствие в TOP10/TOP20/TOP50.
- **FACT:** полный канонический OEM scope содержит 12 запросов. Для УФ 003Б локальные первичные данные также содержат `97133F2100` и `97133F2200`; свежих позиций по ним нет.
- **FACT:** подключение к встроенному браузеру завершилось техническим сбоем до открытия Ozon. Поэтому новый текущий public-срез для Казани и Новосибирска и текущая Seller-диагностика не получены. Последние региональные Seller-ранги от 2026-09-09 приведены отдельно как `STALE`, а не как текущие публичные позиции.
- **INFERENCE:** на доступных фактах лучший органический профиль сейчас у УФ 001Б и у УФ 003Б по `97133F2000`. Самая тяжёлая подтверждённая проблема — УФ 002Б: глубокие Seller-ранги, слабая накопленная популярность, слабая релевантность `JZW819653F`, ценовой разрыв и исторически более медленная доставка. УФ 004Б показывает частичное восстановление в Москве, но `5Q0819644A` остаётся слабым запросом. УФ 005Б слабее всего по `6479C2`.
- **RECOMMENDATION:** не объявлять восстановление paid traffic обязательным для какого-либо SKU до появления текущего продуктового CPC/campaign state. В доступном EFA Read MCP за 2026-09-04…11 продуктовых CPC-строк нет; `empty != zero` и не доказывает выключенную рекламу. Сначала нужны: повтор текущей Seller/public-матрицы, затем точечная content/relevance проверка 002/004/005 и закрытие product-data конфликта 003.

## Scope and measurement rules

Публичная позиция и Seller search analytics не объединяются. TOP-флаги ниже рассчитаны **только по публичной позиции**. Если карточка не найдена в первых восьми, значение записано `>8 / exact UNKNOWN`, а TOP10/TOP20/TOP50 — `UNKNOWN`, поскольку позиции 9–50 не были просмотрены. Цена — buyer-visible `С банками` из текущего московского buyer context; это не seller realization и не settlement evidence.

`YES*` в поле selected seller означает: в текущей прямой карточке выбран магазин `ЭФА`, но переход из каждой конкретной строки поиска в карточку отдельно не проверен. Для Казани и Новосибирска selected offer не подтверждён.

## Canonical OEM scope

| SKU | Ozon SKU | Canonical OEM | Primary source |
|---|---:|---|---|
| ЭФА УФ 001Б | 4601821825 | `80292SLJ013` | `EFA Products/ЭФА 001Б/ОЕМ 001Б.txt`; migration 020 confirms primary match key |
| ЭФА УФ 002Б | 4642158029 | `6R0820367`; `JZW819653F` | `EFA Products/ЭФА 002Б/ОЕМ 002Б.txt` |
| ЭФА УФ 003Б | 4671345564 | `97133F2000`; `97133F2100`; `97133F2200` | `EFA Products/ЭФА 003Б/ОЕМ 003Б.txt`; migration 020 contains all three match keys |
| ЭФА УФ 004Б | 4642180551 | `5Q0819644A`; `5Q0819653`; `5Q0819669` | `EFA Products/ЭФА 004Б/ОЕМ 004Б.txt` |
| ЭФА УФ 005Б | 4671328307 | `647975`; `6479C2`; `647941` | `EFA Products/ЭФА 005Б/ОЕМ 005Б.txt` |

## Query-level evidence

### ЭФА УФ 001Б

| OEM / query | Region | Seller analytics position | Public position | TOP10 | TOP20 | TOP50 | EFA selected seller | Buyer price | Nearest competitors | Evidence | Confidence |
|---|---|---|---|---|---|---|---|---:|---|---|---|
| `80292SLJ013` | Москва | `STALE 09-09: 9` | **2** | YES | YES | YES | YES* | 607 ₽ | RAF 796591986, rank 1 / 570 ₽ | S-S01; P-M01; C-M01 | HIGH public; MEDIUM historical Seller |
| `80292SLJ013` | Казань | `STALE 09-09: 11` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 796591986 | S-K01 | LOW for current state |
| `80292SLJ013` | Новосибирск | `STALE 09-09: 13` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 796591986 | S-N01 | LOW for current state |

### ЭФА УФ 002Б

| OEM / query | Region | Seller analytics position | Public position | TOP10 | TOP20 | TOP50 | EFA selected seller | Buyer price | Nearest competitors | Evidence | Confidence |
|---|---|---|---|---|---|---|---|---:|---|---|---|
| `6R0820367` | Москва | `STALE 09-09: 164` | `>8 / exact UNKNOWN` | UNKNOWN | UNKNOWN | UNKNOWN | YES* | 637 ₽ | RAF 618137426, rank 3 / 550 ₽; DASHIWA 1284093399 | S-M02A; P-M02A; C-M02 | HIGH bounded public; MEDIUM historical Seller |
| `JZW819653F` | Москва | `STALE 09-09: 87` | `>8 / exact UNKNOWN` | UNKNOWN | UNKNOWN | UNKNOWN | YES* | 637 ₽ | DASHIWA 1284093399; RAF 618137426 | S-M02B; P-M02B; R-REL | HIGH bounded public; MEDIUM historical Seller |
| `6R0820367` | Казань | `STALE 09-09: 191` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | DASHIWA 1284093399 | S-K02 | LOW for current state |
| `JZW819653F` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | DASHIWA 1284093399; RAF 618137426 | DG-01 | UNKNOWN |
| `6R0820367` | Новосибирск | `STALE 09-09: 238` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | DASHIWA 1284093399 | S-N02 | LOW for current state |
| `JZW819653F` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | DASHIWA 1284093399; RAF 618137426 | DG-01 | UNKNOWN |

### ЭФА УФ 003Б

| OEM / query | Region | Seller analytics position | Public position | TOP10 | TOP20 | TOP50 | EFA selected seller | Buyer price | Nearest competitors | Evidence | Confidence |
|---|---|---|---|---|---|---|---|---:|---|---|---|
| `97133F2000` | Москва | `STALE 09-09: 10` | **5** | YES | YES | YES | YES* | 501 ₽ | RAF 434575497, rank 2 / 709 ₽; Wonder Parts 4936120262 | S-M03; P-M03; C-M03 | HIGH public; MEDIUM historical Seller |
| `97133F2100` | Москва | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | YES* direct-card control only | 501 ₽ direct-card control | RAF 434575497 | DG-02 | UNKNOWN |
| `97133F2200` | Москва | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | YES* direct-card control only | 501 ₽ direct-card control | RAF 434575497 | DG-02 | UNKNOWN |
| `97133F2000` | Казань | `STALE 09-09: 9` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | Wonder Parts 4936120262 | S-K03 | LOW for current state |
| `97133F2100` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 434575497 | DG-02 | UNKNOWN |
| `97133F2200` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 434575497 | DG-02 | UNKNOWN |
| `97133F2000` | Новосибирск | `STALE 09-09: 11` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | Wonder Parts 4936120262 | S-N03 | LOW for current state |
| `97133F2100` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 434575497 | DG-02 | UNKNOWN |
| `97133F2200` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 434575497 | DG-02 | UNKNOWN |

### ЭФА УФ 004Б

| OEM / query | Region | Seller analytics position | Public position | TOP10 | TOP20 | TOP50 | EFA selected seller | Buyer price | Nearest competitors | Evidence | Confidence |
|---|---|---|---|---|---|---|---|---:|---|---|---|
| `5Q0819644A` | Москва | `STALE 09-09: 208` | `>8 / exact UNKNOWN` | UNKNOWN | UNKNOWN | UNKNOWN | YES* | 565 ₽ | RAF 613048940, rank 1 / 537 ₽ | S-M04A; P-M04A; C-M04 | HIGH bounded public; MEDIUM historical Seller |
| `5Q0819653` | Москва | `STALE 09-09: 35` | **8** | YES | YES | YES | YES* | 565 ₽ | RAF 613048940, rank 1 / 537 ₽ | S-M04B; P-M04B; C-M04 | HIGH public; MEDIUM historical Seller |
| `5Q0819669` | Москва | `STALE 09-09: 106` | **6** | YES | YES | YES | YES* | 565 ₽ | RAF 613048940, rank 1 / 537 ₽ | S-M04C; P-M04C; C-M04 | HIGH public; MEDIUM historical Seller |
| `5Q0819644A` | Казань | `STALE 09-09: 205` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 613048940 | S-K04 | LOW for current state |
| `5Q0819653` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 613048940 | DG-03 | UNKNOWN |
| `5Q0819669` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 613048940 | DG-03 | UNKNOWN |
| `5Q0819644A` | Новосибирск | `STALE 09-09: 304` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 613048940 | S-N04 | LOW for current state |
| `5Q0819653` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 613048940 | DG-03 | UNKNOWN |
| `5Q0819669` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 613048940 | DG-03 | UNKNOWN |

### ЭФА УФ 005Б

| OEM / query | Region | Seller analytics position | Public position | TOP10 | TOP20 | TOP50 | EFA selected seller | Buyer price | Nearest competitors | Evidence | Confidence |
|---|---|---|---|---|---|---|---|---:|---|---|---|
| `647975` | Москва | `STALE 09-09: 61` | **5** | YES | YES | YES | YES* | 532 ₽ | RAF 332405695, rank 1 / 488 ₽ | S-M05A; P-M05A; C-M05 | HIGH public; MEDIUM historical Seller |
| `6479C2` | Москва | `STALE 09-09: 64` | `>8 / exact UNKNOWN` | UNKNOWN | UNKNOWN | UNKNOWN | YES* | 532 ₽ | RAF 332405695, rank 1 / 488 ₽; IBERIS 1086068777 | S-M05B; P-M05B; R-REL | HIGH bounded public; MEDIUM historical Seller |
| `647941` | Москва | `STALE 09-09: 62` | **8** | YES | YES | YES | YES* | 532 ₽ | RAF 332405695, rank 1 / 488 ₽ | S-M05C; P-M05C; C-M05 | HIGH public; MEDIUM historical Seller |
| `647975` | Казань | `STALE 09-09: 18` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 332405695 | S-K05 | LOW for current state |
| `6479C2` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 332405695; IBERIS 1086068777 | DG-04 | UNKNOWN |
| `647941` | Казань | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 332405695 | DG-04 | UNKNOWN |
| `647975` | Новосибирск | `STALE 09-09: 49` | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 332405695 | S-N05 | LOW for current state |
| `6479C2` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 332405695; IBERIS 1086068777 | DG-04 | UNKNOWN |
| `647941` | Новосибирск | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | RAF 332405695 | DG-04 | UNKNOWN |

## Per-SKU summary

Coverage is reported against the full requested OEM × 3-region matrix. A confirmed TOP count is a lower bound; unresolved rows are not treated as failures.

| SKU | SEARCH_VISIBILITY | Best query | Worst query | Confirmed TOP10 coverage | Confirmed TOP20 coverage | Primary search problem |
|---|---|---|---|---|---|---|
| УФ 001Б | **STRONG** | `80292SLJ013`, public Москва rank 2 | Same query, regional current public ranks UNKNOWN | `≥1 / 3`; 2 unresolved | `≥1 / 3`; 2 unresolved | Competition and locality are residual risks; no current relevance failure is established |
| УФ 002Б | **CRITICAL** | Exact current best UNKNOWN; last Seller best `JZW819653F` rank 87 | `6R0820367`, last Seller 164/191/238 | `0 confirmed / 6`; all 6 unresolved beyond current first-eight or region | `0 confirmed / 6`; all 6 unresolved | Weak behavioral history + weak `JZW` relevance; price, delivery/locality and strong competition amplify the gap |
| УФ 003Б | **MEDIUM** | `97133F2000`, public Москва rank 5 | `97133F2100/2200` — not measured | `≥1 / 9`; 8 unresolved | `≥1 / 9`; 8 unresolved | Coverage gap for two canonical OEMs; product-data conflict must be resolved before content expansion |
| УФ 004Б | **WEAK** | `5Q0819669`, public Москва rank 6 | `5Q0819644A`, current not found in first 8; last Seller 208/205/304 | `≥2 / 9`; 7 unresolved | `≥2 / 9`; 7 unresolved | Query-specific relevance/behavioral history and competition; locality alone did not explain the historical deep rank |
| УФ 005Б | **WEAK** | `647975`, public Москва rank 5 | `6479C2`, current not found in first 8; last Seller relevance 38.8 vs leader 100 | `≥2 / 9`; 7 unresolved | `≥2 / 9`; 7 unresolved | `6479C2` relevance + competition; price and locality are secondary amplifiers |

## Portfolio summary

| SKU | Best current public rank | Worst current public rank | TOP10 coverage | TOP20 coverage | Visibility status | Main problem |
|---|---:|---|---|---|---|---|
| УФ 001Б | 2 | Regional current UNKNOWN | `≥1/3` | `≥1/3` | STRONG | Regional verification gap; competition/locality watch |
| УФ 002Б | UNKNOWN | `>8`, exact current UNKNOWN | `0 confirmed/6` | `0 confirmed/6` | CRITICAL | Behavioral history + JZW relevance; price/locality/competition |
| УФ 003Б | 5 | Two OEMs and regional current UNKNOWN | `≥1/9` | `≥1/9` | MEDIUM | Incomplete OEM measurement; product-data conflict |
| УФ 004Б | 6 | `>8` for 644A; regional current UNKNOWN | `≥2/9` | `≥2/9` | WEAK | 644A relevance/behavioral history + competition |
| УФ 005Б | 5 | `>8` for 6479C2; regional current UNKNOWN | `≥2/9` | `≥2/9` | WEAK | 6479C2 relevance + competition; price/locality |

## Driver diagnosis

### FACT

- Current EFA Read MCP shows all five products active and in stock at the 2026-09-11 stock snapshot. FBO/FBS present: 001 `0/285`, 002 `2/419`, 003 `0/401`, 004 `0/363`, 005 `0/381`. Therefore current portfolio-level out-of-stock is not supported.
- Current internal seller prices checked 2026-09-11 are 953 / 995 / 890 / 995 / 943 ₽. They are not buyer prices. Current Moscow buyer bank prices from the public cards are 607 / 637 / 501 / 565 / 532 ₽.
- Product-level CPC reads for 2026-09-04…11 returned no rows for every SKU. The source explicitly states that absence of a row is not a successful zero observation.
- Last Seller diagnostic on 2026-09-09 rated relevance: 002 `JZW819653F` 23.8 versus leader 85.4; 004 `5Q0819644A` 46.7 versus 96.8; 005 `6479C2` 38.8 versus 100.0. For 003 `97133F2000`, EFA relevance was 79.6 versus leader 66.5.
- Historical regional Seller data shows locality correlation for some SKUs, but not a universal explanation. УФ 004Б remained rank 205 in Kazan despite 0–1-day delivery; УФ 005Б improved from 61 in Moscow to 18 in Kazan alongside different delivery and competitor composition.

### INFERENCE

- **УФ 001Б:** current Moscow visibility is genuinely strong. The historical 9→11→13 regional gradient is consistent with locality/delivery pressure, but the current public regional gradient is unverified.
- **УФ 002Б:** the strongest combined explanation is insufficient behavioral history plus query-specific relevance weakness. Higher buyer price than RAF, slower historical delivery and mature competitors are credible amplifiers, not isolated root causes.
- **УФ 003Б:** price is unlikely to be the immediate visibility constraint on `97133F2000`; the current public price is below the selected RAF comparator and the Moscow rank is 5. The missing 2100/2200 measurements and unresolved dimensions conflict prevent a broad content conclusion.
- **УФ 004Б:** post-publication recovery on 653/669 is observable, while 644A remains weaker. Since fast Kazan delivery previously coexisted with rank 205, locality/FBO is not a sufficient explanation. Relevance, historical traffic/behavior and competition are more plausible, but causality is unconfirmed.
- **УФ 005Б:** weakness is query-specific rather than total; `647975` and `647941` are currently visible in Moscow, while `6479C2` is not in the first eight. Low historical relevance for C2 and RAF dominance support a content/relevance + competition diagnosis; locality and a +44 ₽ current buyer-price gap may contribute.

### RECOMMENDATION

- **Already showing good organic search:** УФ 001Б; УФ 003Б only for `97133F2000`. УФ 004Б and УФ 005Б have partial Moscow visibility, not portfolio-wide strong organic coverage.
- **Paid traffic recovery required now:** `NOT CONFIRMED` for every SKU. Current CPC/campaign state and paid/organic split are unavailable. Candidate for a later isolated paid assessment: УФ 002Б after relevance/offer controls; УФ 004Б only after a fresh post-content regional baseline. Do not restart paid traffic from this report.
- **Content/relevance correction first:** УФ 002Б (`JZW819653F`); УФ 004Б (`5Q0819644A`, remeasure before any further edit); УФ 005Б (`6479C2`). For УФ 003Б, resolve the dimensional/product-passport conflict before any content correction or compatibility expansion.
- **Locality/FBO investigation:** prioritize 002 and 005 as scenario checks; treat 001 as a regional continuity watch. Do not infer a stock-placement action without W06 economics and owner authorization.

## Data gaps

| ID | Missing evidence | Impact |
|---|---|---|
| DG-01 | Current Seller and public ranks for `JZW819653F` in Kazan/Novosibirsk | Full regional TOP coverage for УФ 002Б cannot be calculated |
| DG-02 | Current ranks for `97133F2100` and `97133F2200` in all three regions | Two of three canonical OEMs for УФ 003Б are unmeasured |
| DG-03 | Current Seller/public ranks for 653/669 outside Moscow | Regional recovery of УФ 004Б cannot be claimed |
| DG-04 | Current Seller/public ranks for C2/941 outside Moscow | Regional query dispersion of УФ 005Б remains unresolved |
| DG-05 | Public positions 9–50 for current Moscow queries not found in first eight | TOP10/TOP20/TOP50 cannot be classified for those rows |
| DG-06 | Current public search for Kazan and Novosibirsk | Locality comparison is historical Seller evidence only |
| DG-07 | Current Seller query diagnostic for 2026-09-11 | Internal rank column remains a 2026-09-09 stale reference |
| DG-08 | Product-level CPC/campaign state and paid/organic split | Paid-traffic recovery cannot be prescribed |
| DG-09 | Query-path selected offer for each region/query | Direct-card seller match cannot be generalized to every search path |

## Sources / Evidence

| Code | Source | Observation / freshness |
|---|---|---|
| P-M01…P-M05 | `OZON_AI_AGENTS/REPORTS/W01/DAILY/2026-09-11/W01_MARKET_REPORT.md` | Current public Moscow buyer context; direct cards and first eight results; completed 2026-09-11 08:15:45 MSK |
| C-M01…C-M05 | Same current W01 report, competitor and price-gap sections | Current nearest bounded competitors and buyer display prices |
| S-* | `OZON_AI_AGENTS/REPORTS/RESEARCH/EFA_SEARCH_RELEVANCE_DIAGNOSTIC_V1.md` and `EFA_OFFER_SELECTION_REGIONAL_MATRIX_V1.md` | Seller diagnostic observed 2026-09-09; `STALE` for a current 2026-09-11 claim |
| R-REL | `EFA_SEARCH_RELEVANCE_DIAGNOSTIC_V1.md` | Historical Seller relevance/leader comparison; not a current public rank |
| EFA-READ-01 | EFA Read MCP `list_products` + `get_product_overview`, correlation IDs preserved in task run | Product state observed/checked 2026-09-11; stock snapshot 2026-09-11 03:00Z; internal seller price is not buyer price |
| EFA-READ-CPC | EFA Read MCP `get_cpc_daily`, 2026-09-04…11 | Empty product result for all five; missing is not zero |
| OEM-LOCAL | `EFA Products/ЭФА 001Б…005Б/ОЕМ 00xБ.txt` | Local primary product material; approval date not encoded in files |
| OEM-SEED | `database/migrations/020_competitor_monitor_initial_watchlist_seed_v1.sql` | Tracked historical seed; confirms match keys, not current marketplace state |
| BROWSER-ERR | Built-in browser connection attempt, 2026-09-11 | Two attempts plus reset failed before opening Ozon: browser inventory returned invalid HTML/JSON response |

## Run receipt

- Run type: `W01_EFA_ALL_SKU_CURRENT_SEARCH_POSITION_AUDIT_V1`
- Run status: `PARTIAL / BROWSER_ACCESS_BLOCKED`
- SKU covered: `5 / 5`
- Canonical OEM identified: `12 / 12`
- Requested query-region cells: `36`
- Current public cells with exact rank: `6 / 36`
- Current public Moscow queries bounded to first 8: `10 / 12 OEM queries`
- Current public Kazan/Novosibirsk cells: `0 / 24`
- Current Seller analytics cells: `0 / 36`; latest historical Seller reference populated where available
- External write: `NONE`
- Ozon changes: `NONE`
- Automation: `DISABLED`

