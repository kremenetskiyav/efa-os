# W08 Portfolio Strategy Refresh — 13 September 2026

Run ID: `W08_PORTFOLIO_STRATEGY_REFRESH_SEP13_V1`  
Role: `W08 — Commercial Analyst`  
Mode: `READ / PROPOSE`  
External write: `NONE`  
Execution Plane: `NOT READY`

## Decision

**Portfolio paid policy remains `NO TEST NOW`.** The current confirmed state `CPC OFF 5/5` and `CPO OFF 5/5` should be preserved. УФ004 remains the only conditional controlled-test candidate, but its `20.11%` LAST_7_DAYS proxy does not clear the gate because CURRENT_MONTH is only `13.28%` before unallocated advertising. УФ001/002/003 are below the 12% floor before advertising in both current windows. УФ005 is blocked by a short-window loss and return/logistics concentration despite a positive MTD proxy.

The only role change is `УФ003Б: HOLD → FIX_FIRST`.

No `CPC_ACTION`, `CPO_ACTION`, `PROMOTION_ACTION`, price action or execution authorization is created.

## Evidence boundary

- Financial windows are `LAST_7_DAYS = 2026-09-06…12` and `CURRENT_MONTH = 2026-09-01…12`, Europe/Moscow.
- Margins are `SELLER_SIDE_PROXY / contribution before unallocated account advertising`, not final profit or settlement contribution.
- W06 remains `INSUFFICIENT_SETTLEMENT_DATA`; current COGS is a low-confidence proxy and complete costs are false.
- Account advertising charges remain unallocated: `6,417.91 ₽` LAST_7_DAYS and `11,824.27 ₽` CURRENT_MONTH. Current CPC/CPO OFF does not erase historical period charges.
- Demand coverage is incomplete: 5/7 days for LAST_7_DAYS and 9/12 days for CURRENT_MONTH. The margin source is the separate provisional Seller Unit Economics order cohort; demand gaps block funnel and causal claims.
- The user-confirmed `CPC OFF 5/5 / CPO OFF 5/5` is the newest current-state authority and supersedes older active-state observations. It was not independently re-read from Ozon in this run.
- W01 search evidence is the latest available 11 September bounded snapshot, not a new 13 September search read.

## September economics

| SKU | LAST_7_DAYS seller realization / delivered | 7d contribution before ads | 7d margin | CURRENT_MONTH seller realization / delivered | MTD contribution before ads | MTD margin | Floor status |
|---|---:|---:|---:|---:|---:|---:|---|
| УФ001Б | `6,600 ₽ / 10` | `570.89 ₽` | `8.65%` | `14,526 ₽ / 22` | `1,248.45 ₽` | `8.59%` | Below 12% in both windows |
| УФ002Б | `2,836 ₽ / 4` | `312.57 ₽` | `11.02%` | `9,217 ₽ / 13` | `1,001.33 ₽` | `10.86%` | Below 12% in both windows |
| УФ003Б | `5,072 ₽ / 8` | `286.33 ₽` | `5.65%` | `18,338 ₽ / 28` | `1,708.21 ₽` | `9.32%` | Below 12% in both windows |
| УФ004Б | `3,903 ₽ / 5` | `784.92 ₽` | `20.11%` | `5,651 ₽ / 8` | `750.69 ₽` | `13.28%` | 7d target pass; MTD only 1.28 pp above floor |
| УФ005Б | `853 ₽ / 1` | `−200.91 ₽` | `−23.55%` | `9,383 ₽ / 11` | `1,496.45 ₽` | `15.95%` | Window conflict; 7d severe fail |

Before any advertising allocation, the shortfall to the 12% floor is:

- УФ001Б: `221.11 ₽` in 7d and `494.67 ₽` MTD.
- УФ002Б: `27.75 ₽` in 7d and `104.71 ₽` MTD.
- УФ003Б: `322.31 ₽` in 7d and `492.35 ₽` MTD.
- УФ004Б: no pre-ad floor shortfall; MTD headroom is only `72.57 ₽`, while the MTD shortfall to the 15% target is `96.96 ₽`.
- УФ005Б: the 7d shortfall to floor is `303.27 ₽`; MTD headroom over the 15% target is only `89.00 ₽` before unallocated advertising.

## Required portfolio output

| SKU | Current role | Recommended role | 7d margin | MTD margin | Main problem | Paid policy | Promotion policy | Next action | Stop condition | Priority |
|---|---|---|---:|---:|---|---|---|---|---|---|
| УФ001Б | `DEFEND` | `DEFEND` | `8.65%` | `8.59%` | `ECONOMICS`; search is already strong at rank 2 | `NO` | `NO NEW PROMOTION`; preserve only a no-change observation state | W06: identify the commission/logistics/realization or price-setting path that restores ≥15%; W01: protect rank 2 | No paid/promo consideration while either current window is <12%; stop any future proposal if rank/offer deteriorates | `#4 / DEFEND ORGANIC` |
| УФ002Б | `FIX_FIRST` | `FIX_FIRST` | `11.02%` | `10.86%` | `ECONOMICS + SEARCH/CONTENT`; both OEM queries outside first 8 | `NO` | `NO` | Complete relevance, selected-offer, buyer-price and delivery diagnostic; quantify economics repair before traffic | Any margin <12%, unresolved `JZW819653F` relevance, or unstable selected offer | `#5 / STRUCTURAL FIX` |
| УФ003Б | `HOLD` | `FIX_FIRST` | `5.65%` | `9.32%` | `ECONOMICS`, then product-data/content conflict | `NO` | `NO NEW/DEEPER PROMOTION`; existing participation requires W06 review | Resolve product passport/dimensions conflict; reconcile why current economics deteriorated; measure 2100/2200 search | Any margin <12%, unresolved product facts, or incomplete OEM search baseline | `#3 / ECONOMICS FIX` |
| УФ004Б | `RECOVER` | `RECOVER` | `20.11%` | `13.28%` | `MTD ECONOMICS RESILIENCE + SEARCH_VISIBILITY`; 644A remains weak | `CONDITIONAL TEST_ONLY, NOT NOW` | `HOLD CURRENT CONFIGURATION / NO EXPANSION` | Keep CPC/CPO OFF; close another clean no-paid observation and allocate historical ads; refresh all three OEM ranks | No test if MTD fully loaded margin <15%, either window <12%, ad allocation unresolved, or more than one lever changes | `#1 / TEST CANDIDATE BLOCKED` |
| УФ005Б | `FIX_FIRST` | `FIX_FIRST` | `−23.55%` | `15.95%` | `ECONOMICS VOLATILITY / RETURN-LOGISTICS MIX`, then weak `6479C2` visibility | `NO` | `HOLD / NO NEW PROMOTION` | Reconcile 7d return/logistics events to orders and settlement; obtain a second stable 7d window before any traffic decision | Any negative current window, return-event concentration, unallocated advertising, or <15% fully loaded margin | `#2 / URGENT DIAGNOSTIC` |

Priority ranks the next commercial decision work, not permission to spend advertising budget. Paid-spend Priority A remains empty.

## Role decisions and mechanism

### УФ001Б — keep `DEFEND`

Search is not the binding problem: the current bounded Moscow rank is 2. Both current margins are stable around 8.6% before advertising, below the hard floor. Paid traffic would buy more demand into a structurally inadmissible contribution base. The commercial job is to preserve the organic asset while W06/Pricing & Economics repairs seller-side economics; W08 does not set the price.

### УФ002Б — keep `FIX_FIRST`

The SKU is close to but still below floor in both windows, and search visibility is critical. A traffic test would combine an uneconomic base with a weak landing/search proposition. Prerequisites are economics ≥15%, query relevance, selected offer, buyer-price competitiveness and delivery/locality evidence. Reaching 12% alone is a survival gate, not a test budget.

### УФ003Б — change `HOLD` to `FIX_FIRST`

The August near-floor signal has been superseded by `5.65%` 7d and `9.32%` MTD. This is not a narrow advertising-headroom problem anymore; it is a base-economics failure before advertising. Rank 5 on `97133F2000` does not justify paid traffic, and two canonical OEM queries plus the product-data conflict remain unresolved.

### УФ004Б — keep `RECOVER`, but do not test yet

The 7d proxy supports candidacy, not launch. At `20.11%`, the 7d cohort has `199.47 ₽` headroom to the 15% target and `316.56 ₽` to the 12% floor before unallocated advertising. The broader MTD cohort is only `13.28%`: it is `96.96 ₽` short of 15% and has just `72.57 ₽` to the floor. A single strong short window cannot override the broader cohort, return maturity or unallocated advertising.

УФ004 becomes testable only after a clean no-paid observation, full allocation of period CPC/CPO, stable stock/offer/delivery, refreshed three-query visibility, and W06 confirmation that both current windows retain ≥15% after all attributable costs. Any later experiment must isolate one mechanism; CPC and CPO must not overlap.

### УФ005Б — keep `FIX_FIRST`

The `−23.55%` 7d versus `15.95%` MTD gap is primarily a concentration/timing effect in the available accounting decomposition:

- LAST_7_DAYS has only `1` delivered unit and `853 ₽` seller realization, but `3` logistics-return events.
- That short window carries `285 ₽` logistics, `165 ₽` other costs, `24.67 ₽` last mile, `20 ₽` processing and `9.39 ₽` acquiring, producing `−200.91 ₽` contribution before ads.
- CURRENT_MONTH has `11` delivered units, `9,383 ₽` seller realization and `5` logistics-return events, producing `1,496.45 ₽ / 15.95%` before ads.

Thus the 7d result is dominated by a tiny delivered denominator and concentrated return/logistics/other-cost events. This is an accounting explanation, not proof of the operational cause of returns and not proof that the underlying SKU has structurally become loss-making. Conversely, the positive MTD average cannot dismiss the recent loss. Order/posting linkage and lifecycle maturity are required before changing the role or reopening paid traffic.

## Gates before any CPC/CPO restart

| SKU | Required conditions before CPC/CPO can even be proposed |
|---|---|
| УФ001Б | Both 7d and MTD fully loaded contribution ≥15%; current search need beyond rank 2 demonstrated; incremental-profit hypothesis; exact W06 cap; isolated mechanism; Owner approval. |
| УФ002Б | Both margins ≥15%; relevance and selected-offer controls fixed; delivery/locality stable; clean search baseline; exact W06 cap; isolated mechanism; Owner approval. |
| УФ003Б | Both margins ≥15%; product-data conflict closed; all three OEM query baselines measured; exact W06 cap; isolated mechanism; Owner approval. |
| УФ004Б | Another mature no-paid window; 7d and MTD ≥15% after allocated historical advertising and complete test-relevant costs; three-query baseline; stable stock/offer/delivery/promotion; exact bid, budget and stop-loss; CPC-only or CPO-only; Owner approval. |
| УФ005Б | Return/logistics reconciliation; at least two consecutive mature 7d windows ≥15% and MTD ≥15% after all ads; `6479C2` prerequisite fixed; exact rate/cost cap; no 10% CPO restoration; isolated mechanism; Owner approval. |

Common hard stop: `contribution <12%`, unknown seller realization, unallocated test advertising, attribution not matured, stock/offer/delivery change, or simultaneous commercial levers.

## Rejected alternative

**Rejected:** immediately run a controlled CPC test on УФ004 because the 7d pre-ad margin is 20.11%.

The option loses because MTD is only 13.28%, the MTD target gap is 96.96 ₽, account advertising remains unallocated, the 7d cohort has only five delivered units plus return events, and search evidence is two days older than the financial refresh. The evidence supports candidacy and continued observation, not paid execution.

## Measurement and reversal evidence

The strategy should be reconsidered when W06 produces a current fully loaded proxy with attributable advertising and mature returns. The key decision metrics are:

1. contribution after all attributable costs in both 7d and MTD windows;
2. incremental contribution per test, not campaign-attributed GMV or DRR;
3. stable selected offer, stock, delivery and promotion state;
4. query-level search positions for the canonical OEM set;
5. return/cancellation maturity and advertising attribution lag.

Reversal rules:

- УФ001/002/003 can move from `NO` to `TEST_ONLY` only after both current windows are ≥15% and their non-economic prerequisites are closed.
- УФ004 can move from `RECOVER / blocked candidate` to an owner-ready isolated test when both windows are ≥15% after all attributable costs.
- УФ005 can leave `FIX_FIRST` only after the return/logistics spike is reconciled and stability is repeated across at least two mature 7d windows.

Confidence:

- Role and `NO TEST NOW`: `HIGH` within the current proxy boundary.
- УФ005 accounting decomposition: `HIGH` for arithmetic, `MEDIUM` for interpretation, `LOW` for operational root cause.
- Future test affordability: `LOW / NOT YET COMPUTABLE` because advertising is unallocated and settlement remains incomplete.

## Handoff to W00

1. Preserve `CPC OFF 5/5` and `CPO OFF 5/5`.
2. Route УФ003 role change to `FIX_FIRST`.
3. Route УФ005 return/logistics reconciliation to W06 as the urgent diagnostic.
4. Keep УФ004 as the only future controlled-test candidate, with no current action and the exact gates above.
5. Do not convert this diagnosis into price, promotion, CPC, CPO or Elastic execution.

## Sources

| Source | Use | Limitation |
|---|---|---|
| `OZON_AI_AGENTS/REPORTS/W06/SNAPSHOTS/2026-09-13/W06_FINANCE_SNAPSHOT_20260913T140009808173Z_LAST_7_DAYS.json` | 7d seller-side economics | Partial, current COGS proxy, incomplete demand, ads unallocated |
| `OZON_AI_AGENTS/REPORTS/W06/SNAPSHOTS/2026-09-13/W06_FINANCE_SNAPSHOT_20260913T140011065801Z_CURRENT_MONTH.json` | MTD seller-side economics | Partial, current COGS proxy, incomplete demand, ads unallocated |
| `OZON_AI_AGENTS/REPORTS/W08/STRATEGY/2026-09-12/W08_EFA_PORTFOLIO_PROMOTION_STRATEGY_V1.md` | Previous roles, August policy and action gates | Superseded for financial direction by current-period evidence |
| `REPORTS/W01/SEARCH_AUDIT/2026-09-11/W01_EFA_ALL_SKU_CURRENT_SEARCH_POSITION_AUDIT_V1.md` | Latest available bounded search visibility | Moscow first-eight scope; regional/current Seller gaps; 11 Sep cutoff |
| Owner-confirmed current paid state | CPC OFF 5/5; CPO OFF 5/5 | Supplied in task; no independent live Ozon read in this run |

## Governance closure

- Ozon changes: `0`
- CPC/CPO changes: `0`
- Promotion/price/Elastic changes: `0`
- `CPC_ACTION`: `NOT CREATED`
- `CPO_ACTION`: `NOT CREATED`
- `PROMOTION_ACTION`: `NOT CREATED`
- Owner approval granted by this report: `NO`
- External write: `NONE`
