# W04_EFA_001_002_003_005_CONTENT_RATING_AUDIT_V1

| Field | Value |
| --- | --- |
| Project | EFA OS / OZON AI-Agents |
| Producer Work | W04 |
| Producer type | `SUPPORT_PRODUCER` |
| Canonical source role | `NOT_CANONICAL_ROLE` |
| Canonical status | `NOT_EMITTED` |
| Canonical decision_id | `NONE` |
| Mode | `READ-ONLY` |
| Observed | 2026-09-12, 12:58–13:11 MSK |
| Freshness | Current Seller-form observations: `FRESH` |
| External write | `NONE` |
| Ozon fields changed | `NO` |
| Media changed or created | `NO` |

## 1. Executive result

The maximum score reachable without any media change is:

- УФ 001Б: **77.5**, gain **+12.5** through the missing Rich-content requirement;
- УФ 002Б: **77.5**, gain **0**;
- УФ 003Б: **68.5**, gain **+12.5** through the missing Rich-content requirement;
- УФ 005Б: **68.5**, gain **0**.

Ozon displays the High boundary at **80 points**: each current card shows the exact remaining distance to High, and the arithmetic resolves to 80. Therefore none of the four cards can reach High under the current no-media constraint.

The score is not a truth-validation result. All four cards receive **30/30** for characteristics even though relevant fields are blank and УФ 003Б contains a confirmed cross-source height conflict.

## 2. Portfolio table

| SKU | Ozon SKU / product edit ID | Current score | Max without media | Title | Description | Characteristics | Rich content | Applicability cleanup | Expected gain |
| --- | --- | ---: | ---: | --- | --- | --- | --- | --- | ---: |
| ЭФА УФ 001Б | `4601821825` / `4861934525` | 65.0 | **77.5** | `REWRITE` | `REWRITE` | 30/30; quality gaps | `YES`, rating lever | Required; typo and broad years | **+12.5** |
| ЭФА УФ 002Б | `4642158029` / `4861934539` | 77.5 | **77.5** | `REWRITE` | `REWRITE` | 30/30; quality gaps | `NO` for rating-only scope | Required; structured list empty and text list unverified | **0** |
| ЭФА УФ 003Б | `4671345564` / `4861934541` | 56.0 | **68.5** | `REWRITE` | `REWRITE` | 30/30; **height conflict** | `YES`, rating lever | Required; current list not approved | **+12.5** |
| ЭФА УФ 005Б | `4671328307` / `4861934542` | 68.5 | **68.5** | `REWRITE` | `REWRITE` | 30/30; verification gap | `NO` for rating-only scope | Required; broad years and 25 structured rows | **0** |

## 3. Exact current rating and missing checklist

| SKU | Overall | To High | Media /45 | Characteristics /30 | Description /25 | Exact missing Ozon items |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| УФ 001Б | 65.0 | 15.0 | 22.5 | 30 | 12.5 | Media: `3 Фото`; `Видео` **или** `Видеообложка`. Description: `Rich-контент`. |
| УФ 002Б | 77.5 | 2.5 | 22.5 | 30 | 25 | Media: `1 Фото`; `Видео` **или** `Видеообложка`. No non-media checklist deficit shown. |
| УФ 003Б | 56.0 | 24.0 | 13.5 | 30 | 12.5 | Media: `4 Фото`; `Видео` **или** `Видеообложка`. Description: `Rich-контент`. |
| УФ 005Б | 68.5 | 11.5 | 13.5 | 30 | 25 | Media: `4 Фото`; `Видео` **или** `Видеообложка`. No non-media checklist deficit shown. |

The exact photo wording is a deficit to the eight-photo checklist, not the current photo count. Current accepted counts are therefore 5 / 7 / 4 / 4 respectively. Video and video cover are absent. Rich-content JSON is empty on all four cards.

The category average displayed during this run is **29.3 points**.

## 4. УФ 001Б

### Rating output

- Current rating: **65.0**.
- Reachable without media changes: **77.5**.
- Missing rating points inside the allowed non-visual scope: **12.5** for `Rich-контент`.
- TITLE: `REWRITE`.
- DESCRIPTION: `REWRITE`.
- CHARACTERISTICS: `complete by score / quality gaps`.
- RICH CONTENT: recommended `YES` as a text-first package.
- CURRENT APPLICABILITY: `needs cleanup`.

### Title audit

Observed title, 127 characters:

> Салонный угольный фильтр для Honda Civic 8 (FD,FA), Civic IX (FK_) / CR-V 3 /4, Accord 8 / 9, Фильтр салона Хонда Цивик, Аккорд

Findings:

- product type and carbon execution are present;
- brand `ЭФА`, article `УФ 001Б` and OEM are absent;
- `Салонный угольный фильтр` / `Фильтр салона` duplicates the product type;
- Latin/Russian vehicle duplication and the model chain reduce readability;
- vehicle wording must not be finalized before `W02_EFA_001_002_003_005_RUSSIA_APPLICABILITY_REFRESH_V1`.

### Description / annotation audit

The annotation is a semicolon-separated keyword block followed by a broad vehicle/year list. It has no OEM, dimensions, construction explanation, package statement or Russia statement. `CR-8` is an evident text error. `Accord 9 (2013–2025)` and other broad ranges require W02 review before reuse.

### Characteristics and facts

- Brand: `Эфа`; article/model and manufacturer part number: `УФ 001Б`.
- OEM in Ozon: `80292SLJ013`; local primary record also gives `Honda 80292-SLJ-013`.
- Execution: `Фильтр из активированного угля`; form: `Прямоугольник`; country: `Россия`; one unit.
- Ozon dimensions: `234 × 224 × 30 мм`; they match the local primary size file.
- `Вид воздушного фильтра`: blank; `Материал`: blank.
- Current structured applicability contains at least 25 rows; three visible rows are Honda Civic VIII modifications. The complete list was not approved as final applicability.
- Local data uses `MANN CU 2358` while the product is described as carbon; the earlier W02 finding requires normalization against the carbon variant naming before this cross-reference appears in content.

### Main rating gains

1. Add an approved text-first Rich-content structure: **+12.5** description points if accepted by Ozon.
2. Rewrite title and annotation for identity, OEM and readability: **quality/SEO gain, no separate rating points displayed**.
3. Clean applicability after W02 refresh: **fact-safety gain, no separate rating points displayed**.

## 5. УФ 002Б

### Rating output

- Current rating: **77.5**.
- Reachable without media changes: **77.5**.
- Missing rating points inside the allowed non-visual scope: **0**.
- TITLE: `REWRITE`.
- DESCRIPTION: `REWRITE`.
- CHARACTERISTICS: `complete by score / quality gaps`.
- RICH CONTENT: recommended `NO` for rating-only scope; optional later for buyer clarity.
- CURRENT APPLICABILITY: `needs cleanup`.

### Title audit

Observed title, 170 characters:

> Салонный угольный фильтр для Volkswagen Polo 5 / 6 Sedan, Skoda Rapid 1 / 2, Fabia 2 / 3, Audi A1 8X, Фильтр салона Поло 5 Поло Седан 6 Седан, Шкода Рапид, Фабиа, Ауди А1

Findings:

- product type and carbon execution are present;
- brand, article and both OEM values are absent;
- long model chain, Russian/Latin duplication and repeated `Поло` are model spam;
- exact vehicle families must wait for W02 refresh.

### Description / annotation audit

Ozon awards 25/25, but the annotation remains only a semicolon-separated keyword list. It has no connected explanation, OEM, dimensions, construction, package or Russia statement. Full score therefore does not mean content completeness for the buyer.

### Characteristics and facts

- OEM: `6R0820367; JZW819653F`.
- Carbon execution, rectangular form, Russia and one unit are present.
- Ozon dimensions: `224 × 254 × 36 мм`; they match the local primary file.
- `Вид воздушного фильтра`: blank; `Материал`: blank.
- Structured applicability rows are empty, while the title/annotation carry a broad unstructured vehicle list.

### Main rating gains

1. No non-media numeric gain remains: description and characteristics already total 55/55.
2. Rewrite title and annotation around product identity and confirmed OEM: **quality/SEO gain only**.
3. Populate or clean structured applicability only after W02 refresh: **fact-safety gain only**.

## 6. УФ 003Б

### Rating output

- Current rating: **56.0**.
- Reachable without media changes: **68.5**.
- Missing rating points inside the allowed non-visual scope: **12.5** for `Rich-контент`.
- TITLE: `REWRITE`.
- DESCRIPTION: `REWRITE`.
- CHARACTERISTICS: `gaps / blocking conflict`.
- RICH CONTENT: recommended `YES`, but dimensions/applicability must remain excluded until resolved.
- CURRENT APPLICABILITY: `needs cleanup / HOLD for final wording`.

### Title audit

Observed title, 160 characters:

> Салонный угольный фильтр для Hyundai Elantra AD, Tucson 3, Kia Ceed 3, Cerato 4, Sportage 4, Фильтр салона Хендай Элантра ад, Туксон, Киа Сид, Церато, Спортейдж

Findings:

- product type and carbon execution are present;
- brand, article and OEM are absent;
- model chain and transliteration duplicates are excessive;
- current applicability must not be converted into final title wording while the SKU remains affected by the existing W02 conflict.

### Description / annotation audit

The annotation is a long keyword list plus seven unconditional Hyundai/Kia family names. It lacks OEM, dimensions, package, Russia and an OEM/VIN condition. Rich-content is absent and is the exact Ozon description gap.

### Characteristics and conflict

- OEM: `97133F2000; 97133F2100; 97133F2200`.
- Carbon execution, rectangular form, Russia and one unit are present.
- Ozon states `238 × 194 × 28 мм`.
- Local primary size file states `238 × 194 × 20 мм`.
- This is `CONTENT_CONFLICT_FIX`; do not choose either height for new publication text until the product record is resolved.
- `Вид воздушного фильтра`: blank; `Материал`: blank; structured applicability rows are empty.

### Main rating gains

1. Add text-first Rich-content using only uncontested facts: **+12.5** if accepted.
2. Resolve the 28/20 mm conflict before any dimensions copy: **blocking fact-safety requirement, not a scored lever**.
3. Rewrite title/annotation and keep vehicle applicability out until W02 refresh: **quality/SEO gain only**.

## 7. УФ 005Б

### Rating output

- Current rating: **68.5**.
- Reachable without media changes: **68.5**.
- Missing rating points inside the allowed non-visual scope: **0**.
- TITLE: `REWRITE`.
- DESCRIPTION: `REWRITE`.
- CHARACTERISTICS: `complete by score / verification gap`.
- RICH CONTENT: recommended `NO` for rating-only scope; optional later for buyer clarity.
- CURRENT APPLICABILITY: `needs cleanup`.

### Title audit

Observed title, 100 characters:

> Салонный угольный фильтр для Citroen C4 1 и 2, Peugeot 308 1, Фильтр салона Ситроен С4 1 2, Пежо 308

Findings:

- product type and carbon execution are present;
- brand, article and all three OEM values are absent;
- product type and vehicle names are duplicated in Latin/Russian forms;
- `C4 1 и 2` and `Peugeot 308 1` are imprecise customer-facing model notation.

### Description / annotation audit

Ozon awards 25/25, but the annotation is a keyword list plus broad statements `Citroen C4 I (2004–2022)`, `Citroen C4 II (2004–2022)` and `Peugeot 308 I (2007–2021)`. It lacks OEM, dimensions, construction, package, Russia and an OEM/VIN check. The equal 2004–2022 ranges for C4 I and II require W02 review.

### Characteristics and facts

- OEM: `647975; 6479C2; 647941`.
- Carbon execution, rectangular form, Russia and one unit are present.
- Ozon and the local primary file both state `178 × 285 × 30 мм`.
- Earlier W02 evidence records an external MANN CUK 2940 discrepancy (`285 × 176 × 36 мм`). This does not overwrite EFA's primary product dimensions, but it blocks using the competitor cross as dimension confirmation until reconciled.
- `Вид воздушного фильтра`: blank; `Материал`: blank.
- Structured applicability contains at least 25 rows; the first visible rows are specific Citroen C4 I modifications. Full matrix approval is absent.

### Main rating gains

1. No non-media numeric gain remains: description and characteristics already total 55/55.
2. Rewrite title and annotation around product identity and OEM: **quality/SEO gain only**.
3. Reconcile applicability and dimension-cross evidence before final vehicle/dimension wording: **fact-safety gain only**.

## 8. Rich-content conclusion

- Rich-content is counted under `Описание товара`, not under `Медиа`.
- For УФ 001Б and УФ 003Б, Ozon explicitly lists `Rich-контент` as the only description checklist gap. Closing it can add **12.5 points per SKU** without changing the existing photo set.
- A text-first Rich-content implementation can be scoped to native text blocks and therefore does not require editing existing images. Actual Ozon acceptance and score recalculation must be verified after a separately approved publication.
- УФ 002Б and УФ 005Б already receive 25/25 for Description with empty Rich-content JSON. Rich-content is therefore not a rating lever for them in the current UI.
- Seller wording states that Rich-content hides the annotation visually, while annotation text continues to affect search. The existing annotation must therefore be rewritten and preserved as searchable text before any future Rich-content publication.

## 9. Characteristic gap matrix

| Field | УФ 001Б | УФ 002Б | УФ 003Б | УФ 005Б | Rating effect shown by Ozon |
| --- | --- | --- | --- | --- | --- |
| Исполнение фильтра | Carbon value present | Present | Present | Present | Included in current 30/30, isolated points not shown |
| Вид воздушного фильтра | Blank | Blank | Blank | Blank | No current deduction shown |
| Материал | Blank | Blank | Blank | Blank | No current deduction shown; do not invent an enum |
| Dimensions | Matches primary | Matches primary | **28/20 conflict** | Primary matches Ozon; external-cross conflict remains | No current deduction shown |
| Form | Rectangular | Rectangular | Rectangular | Rectangular | No isolated points shown |
| Country | Russia | Russia | Russia | Russia | No isolated points shown |
| Article / part number | Present | Present | Present | Present | No isolated points shown |
| OEM | Present | Present | Present | Present | No isolated points shown |
| Structured applicability | ≥25 rows, unapproved complete matrix | Empty | Empty | ≥25 rows, unapproved complete matrix | No current deduction shown |

## 10. Three portfolio proposals

All proposals are `NOT PUBLISHED / OWNER APPROVAL REQUIRED`.

### P1 — Title normalization for all four SKU

- Operational labels: `TITLE_CHANGE`, `SEO_IMPROVEMENT`.
- Current issue: no brand/article/OEM; repeated product type; Russian/Latin vehicle duplication; model spam.
- Proposed structure: `Фильтр салонный угольный ЭФА УФ 00xБ, OEM …`; add only W02-confirmed high-priority vehicle families after the pending refresh.
- Claim status: product type/article/OEM can be `CONFIRMED_FACT` when copied from the exact primary record; vehicle wording remains `UNCONFIRMED` until W02 refresh.
- Compatibility review: `REQUIRED` for vehicle terms.
- Expected rating effect: no separate title points displayed; SEO/CTR effect is an `INFERENCE`.

### P2 — Description normalization plus Rich-content for 001Б/003Б

- Operational labels: `DESCRIPTION_CHANGE`, `RICH_CONTENT_CHANGE`, `SEO_IMPROVEMENT`.
- Replace keyword dumps with short readable blocks: product identity, activated-carbon construction, exact OEM, verified dimensions where conflict-free, one-filter package, Russia and OEM/VIN verification rule.
- Add text-first Rich-content to 001Б and 003Б only for the current rating goal.
- Exclude gases, allergens, harmful substances, smog, bacteria, health claims and odour-elimination claims.
- Claim status: confirmed fields `CONFIRMED_FACT`; unverified performance or vehicle scope `UNCONFIRMED` and excluded.
- Compatibility review: `REQUIRED` before vehicle lists.
- Expected rating effect: **+12.5** for 001Б and **+12.5** for 003Б if Ozon accepts and recalculates; 002Б/005Б **0**.

### P3 — Data-quality and applicability gate

- Operational labels: `CONTENT_CONFLICT_FIX`, `CHARACTERISTIC_CHANGE`, `REQUEST_COMPATIBILITY_REVIEW`.
- Route УФ 003Б height `28 мм` in Ozon versus `20 мм` in the primary file for authoritative resolution.
- Route the УФ 005Б external-cross dimension discrepancy and the current 001Б/005Б structured applicability matrices to W02/W00.
- Keep `Материал` empty until an exact supported Ozon enum is confirmed. Evaluate `Вид воздушного фильтра = Угольный` only in a future owner-reviewed diff; it offers no currently visible rating gain.
- Do not populate final vehicle lists before `W02_EFA_001_002_003_005_RUSSIA_APPLICABILITY_REFRESH_V1`.
- Owner direction: required before every Ozon change.

## 11. Sources / evidence

1. Authenticated Ozon Seller edit forms, read-only:
   - УФ 001Б: product edit ID `4861934525`, Ozon SKU `4601821825`;
   - УФ 002Б: `4861934539`, Ozon SKU `4642158029`;
   - УФ 003Б: `4861934541`, Ozon SKU `4671345564`;
   - УФ 005Б: `4861934542`, Ozon SKU `4671328307`.
2. Current title, characteristic, annotation, media and rating read-back observed 2026-09-12, 12:58–13:11 MSK; freshness `FRESH` for the observed card state.
3. Local primary materials:
   - `EFA Products/ЭФА 001Б/ОЕМ 001Б.txt`, `Размеры 001Б.txt`;
   - `EFA Products/ЭФА 002Б/ОЕМ 002Б.txt`, `Размеры 002Б.txt`;
   - `EFA Products/ЭФА 003Б/ОЕМ 003Б.txt`, `Размеры 003Б.txt`;
   - `EFA Products/ЭФА 005Б/ОЕМ 005Б.txt`, `Размеры 005Б.txt`.
4. Existing W02 question/compatibility package, 2026-09-07, for the 003Б conflict, 005Б discrepancy and 001Б cross-reference normalization.
5. `docs/products/product-standard.md` and `docs/marketplace/ozon-standard.md`.

No credentials, cookies, session data or uncontrolled Seller exports were saved.

## 12. Test outcome

- Audit coverage: all four requested SKU and all requested content areas.
- Maximum score without media change calculated: `YES`.
- Exact current checklist captured: `YES`.
- Unsupported claims proposed: `NO`.
- Final vehicle list created: `NO`.
- Images deleted/replaced/reordered/edited/created: `NO`.
- Video added: `NO`.
- Rich-content published: `NO`.
- Ozon save/moderation controls activated: `NO`.
- External write: `NONE`.

