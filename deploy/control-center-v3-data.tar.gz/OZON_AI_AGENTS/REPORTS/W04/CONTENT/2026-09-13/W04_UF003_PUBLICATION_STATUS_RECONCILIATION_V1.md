# W04_UF003_PUBLICATION_STATUS_RECONCILIATION_V1

## Record identity

| Field | Value |
| --- | --- |
| Project | EFA OS / OZON AI-Agents |
| Agent | W04 Content & SEO |
| SKU | ЭФА УФ 003Б |
| Ozon SKU / editor ID | `4671345564 / 4861934541` |
| Mode | `READ + LOCAL RECORD WRITE` |
| External write | `NONE` |
| Latest read-only evidence | `2026-09-13T18:53:27+03:00` |

## Reconciliation result

| Field | Canonical value |
| --- | --- |
| Requested prior execution report | `W04_UF003_CONTENT_PUBLISH_V1` |
| Publication record found before reconciliation | `NO` |
| Canonical publication status | `PUBLISHED` |
| Moderation status | `MODERATION_COMPLETE` |
| Control Center status | `UF003 content state: PUBLISHED / MODERATION_COMPLETE` |
| Content rating | `68.5 / Базовый` |
| Unexpected changes | `NONE` in the supplied post-submit read-back |

## Canonical publication payload

### Final title

`Фильтр салонный угольный ЭФА УФ 003Б для Hyundai Tucson III (TL/TLE), Kia Sportage IV (QL/QLE), OEM 97133F2100, 97133F2200`

### Confirmed content state

| Field | Canonical published value / state | Evidence level |
| --- | --- | --- |
| Description | Updated | Supplied post-submit read-back |
| OEM | `97133F2100; 97133F2200` | Supplied post-submit read-back; matches final package |
| `97133F2000` removed | `YES` | Supplied post-submit read-back |
| Dimensions | `195 × 240 × 29 мм` | Supplied post-submit read-back; matches final package |
| Rich-content | `YES` | Supplied post-submit read-back |
| CPC | `OFF` | Supplied post-submit read-back |
| CPO | `OFF` | Supplied post-submit read-back |
| Elastic | `OFF` | Supplied post-submit read-back |

## Latest live read-only evidence

The authenticated Ozon Seller product list was read without opening an edit or
save flow and without performing any write. At
`2026-09-13T18:53:27+03:00`, the row for Ozon SKU `4671345564` showed:

- status `Продаётся`;
- no `Обновляется` marker;
- the exact final title recorded above;
- content rating `68.5 / Базовый`.

This evidence is newer than the original post-submit state
`Продаётся / Обновляется`. The final title is now active and the rating has been
recalculated to the predicted `68.5`; therefore the canonical moderation state
is advanced from `SUBMITTED / MODERATION_PENDING` to
`PUBLISHED / MODERATION_COMPLETE`.

## Evidence and provenance

1. Owner-supplied known execution result and post-submit read-back in task
   `W04_UF003_PUBLICATION_STATUS_RECONCILIATION_V1`.
2. Authenticated Ozon Seller product-list row for SKU `4671345564`, observed
   read-only at `2026-09-13T18:53:27+03:00`.
3. `W04_UF003_FINAL_CONTENT_PACKAGE_V2.md`, confirming the intended final title,
   OEM family, dimensions, description and Rich-content package.

## Write audit

- Ozon publication repeated: `NO`.
- Ozon edit/save flow opened: `NO`.
- Ozon or other external write: `NONE`.
- Local file created: this canonical reconciliation record only.
