# W04_UF004_CONTENT_V2_PUBLICATION_READBACK

| Field | Value |
| --- | --- |
| Project | EFA OS / OZON AI-Agents |
| Producer Work | `W04` |
| Package | `PACKAGE_UF004_CONTENT_V2` |
| SKU | ЭФА УФ 004Б |
| Ozon SKU | `4642180551` |
| Ozon product editor ID | `4861934500` |
| Date and final read-back | 2026-09-10 22:05 MSK |
| Mode | `OWNER-AUTHORIZED EXTERNAL WRITE / READ-BACK` |
| Execution status | `SUCCESS` |
| Moderation status | `APPLIED`; Seller list: `Продается`, no `Обновляется` marker |
| External writes | One authorized submission of the content package to Ozon moderation |

## 1. Owner authorization and scope

Owner authorized publication only for the following mapping:

1. exact approved title;
2. exact FULL DESCRIPTION from `W04_UF004_CARD_OPTIMIZATION_FINAL_V2` into the single Seller field `Аннотация / Описание товара`;
3. `Вид воздушного фильтра: Угольный`;
4. `Материал` remains empty;
5. all other confirmed fields remain unchanged when already matching the package.

No separate short annotation was published because the current Seller form exposes only one combined product-text field.

## 2. Exact pre-save diff

### Title

**BEFORE**

```text
Салонный угольный фильтр для Audi A3 (8V), Skoda Octavia A7/A8, Volkswagen Tiguan 2, Passat B8, Golf 7 / 8, Jetta 7, Фильтр салона Ауди а3 Шкода Октавиа а7 а8 Фольксваген Тигуан Пассат Гольф Джетта
```

**AFTER**

```text
Фильтр салонный угольный ЭФА УФ 004Б для Skoda Octavia A7 (5E), Volkswagen Tiguan II (AD1/AX1) по OEM 5Q0819644A, 5Q0819669
```

### Аннотация / Описание товара

**BEFORE**

```text
салонный фильтр ауди а 3; салонный фильтр Audi A3 (8V); салонный фильтр шкода октавия а7; салонный фильтр шкода октавия а8; салонный фильтр Skoda Octavia A7 A8; салонный фильтр фольксваген тигуан 2; салонный фильтр Volkswagen Tiguan 2; салонный фильтр Volkswagen Passat B8; салонный фильтр фольксваген пассат б8; салонный фильтр Volkswagen Golf 7 8; салонный фильтр Volkswagen Jetta 7; салонный фильтр фольксваген Джетта
```

**AFTER**

```text
ЭФА УФ 004Б — салонный угольный фильтр с фильтрующим материалом, содержащим активированный уголь. Фильтр задерживает пыль.

OEM для подбора: 5Q0819644A (5Q0 819 644 A), 5Q0819653 (5Q0 819 653), 5Q0819669 (5Q0 819 669). Номера указаны для сопоставления детали; товар выпускается под брендом ЭФА.

Основные подтверждённые семейства применения: Skoda Octavia A7 (5E) и Volkswagen Tiguan II (AD1/AX1). Совместимость подтверждается при совпадении OEM штатного фильтра или по VIN конкретного автомобиля. Совпадения только марки, модели или года недостаточно: проверка требуется для конкретной модификации.

Размеры по спецификации ЭФА: длина 235 мм, ширина 254 мм, высота 30 мм. Форма фильтра — прямоугольная.

Комплектация: один салонный фильтр. Товар поставляется в прозрачном запаянном полимерном пакете с бумажной маркировочной этикеткой ЭФА.
```

### Вид воздушного фильтра

```text
BEFORE: пусто
AFTER:  Угольный
```

### Материал

```text
BEFORE: пусто
AFTER:  пусто
```

## 3. Post-save content read-back

The Seller editor and public buyer card both returned the approved title and exact FULL DESCRIPTION. The public card is already serving the new content.

| Field | Read-back state | Result |
| --- | --- | --- |
| Title | Exact approved title | `PASS` |
| Аннотация / Описание товара | Exact FULL DESCRIPTION | `PASS` |
| OEM | `5Q0819644A; 5Q0819653; 5Q0819669` | `PASS / UNCHANGED` |
| Вид воздушного фильтра | `Угольный` | `PASS / CHANGED` |
| Материал | Empty | `PASS / UNCHANGED` |
| Тип | `Фильтр салонный` | `PASS / UNCHANGED` |
| Исполнение фильтра | `Фильтр из активированного угля` | `PASS / UNCHANGED` |
| Размеры | 235 × 254 × 30 мм | `PASS / UNCHANGED` |
| Артикул | `УФ 004Б` | `PASS / UNCHANGED` |
| Страна | `Россия` | `PASS / UNCHANGED` |
| Форма | `Прямоугольник` | `PASS / UNCHANGED` |
| Применяемость | Empty; not expanded | `PASS / UNCHANGED` |

## 4. Commercial and fulfilment guardrail read-back

| Guardrail | Post-save observation | Result |
| --- | --- | --- |
| Buyer price | 581 ₽ with Ozon banks; 645 ₽ with other banks | `UNCHANGED` |
| Seller price | 865 ₽; crossed-out 4,415 ₽ | `UNCHANGED` |
| Price ceiling | 995 ₽ | `UNCHANGED` |
| CPC | Campaign `41279030` active; average CPC; Search and Recommendations; budget 2,000 ₽ | `UNCHANGED` |
| CPO | Enabled; 23% / 199 ₽; one CPC campaign | `UNCHANGED` |
| Promotion | `Не участвует`; future `Не запланировано` | `UNCHANGED` |
| Elastic | 0%; `Недоступно`; product not in promotion | `UNCHANGED` |
| FBO/FBS stock | FBO 1 / FBS 342 | `UNCHANGED` |
| Media | No write performed | `UNCHANGED` |
| Other SKU | No write performed | `UNCHANGED` |

CPC delivery counters continued accumulating during the observation window (797 → 905 impressions, 6 → 8 clicks, 220.71 → 278.67 ₽ spend). This is normal traffic after the baseline and is not a CPC configuration change caused by the content publication.

The CPO advertising surface temporarily retained the old product-title label while the Seller product list, price surface and public buyer card already displayed the new title. This is classified as propagation lag of a linked display label, not as an unexpected field mutation.

## 5. Final classification and W01 handoff

- Observation class: `UF004_COMMERCIAL_RECOVERY_CONTENT_V2`.
- Attribution: `NOT CLEAN SEO ATTRIBUTION`.
- Reason: CPC/CPO were enabled by Owner on 2026-09-10 before content publication; price and advertising activity also changed within the same calendar day.
- W01 baseline: `W01_UF004_CONTENT_V2_BASELINE_V1`.
- W01 checkpoints ready: T+1 — 2026-09-11; T+3 — 2026-09-13; T+7 — 2026-09-17; T+14 — 2026-09-24.
- Measurement set: OEM positions, Octavia A7 positions, Tiguan II positions, impressions, CPC impressions, clicks, CTR, orders, conversion, CPC spend, CPO cost and buyer price.
- W01 monitoring ready: `YES`.

## 6. Final execution result

- Execution status: `SUCCESS`.
- Moderation/read-back status: `APPLIED`; SKU remains `Продается`, with no pending `Обновляется` marker at final read-back.
- Exact fields changed: title; combined annotation/description field; `Вид воздушного фильтра`.
- Exact fields unchanged: Material, OEM, type, execution, dimensions, article, country, form, applicability, media, prices, price ceiling, promotion, Elastic, CPC/CPO configuration, FBO/FBS and stock.
- Unexpected linked changes: `NONE`.
- External writes performed: one Owner-authorized content-package save/submission for Ozon SKU `4642180551`; no other external writes.
