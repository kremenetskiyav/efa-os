# W04_UF002_CONTENT_PUBLISH_ABORTED_ROLLBACK_V1

| Field | Value |
| --- | --- |
| Project | EFA OS / OZON AI-Agents |
| SKU | ЭФА УФ 002Б |
| Ozon SKU / editor ID | `4642158029 / 4861934539` |
| Source package | `W04_UF002_FINAL_CONTENT_PACKAGE_V2` |
| Date | `2026-09-12` |
| Final status | `ABORTED / ROLLED BACK` |
| Moderation submitted | `NO` |

## Stop trigger

The Ozon Seller pre-submit content-rating forecast showed:

- current overall: `77.5`;
- after moderation: `65`;
- description component after moderation: `12.5 / 25`.

This violated the Owner requirement not to lower the current content rating.
The Owner issued an immediate stop and rollback instruction before submission.

## Draft changes discarded

- proposed title;
- proposed full description;
- `Вид воздушного фильтра = Угольный`;
- temporary structured-applicability rows created during preflight/publish
  preparation.

The Seller action `Отмена` → `Выйти и не сохранять` was used. No save or
moderation submission was performed.

## Read-back after rollback

| Check | Result |
| --- | --- |
| Listing status | `Продается` |
| Title | Restored to the previous long title |
| Content rating | `77.5 / Базовый` |
| Structured applicability | No submitted change |
| Moderation | Not started |
| Price | `310 ₽` in product-list read-back; unchanged by W04 |
| Other SKU | Not changed |

## Additional control finding

During the draft, Seller input handling concatenated part of the previous title
after the proposed title instead of producing a clean replacement. The entire
draft was discarded, so this malformed value did not reach moderation.

## External-write classification

- Temporary unsaved Seller draft: `CREATED AND DISCARDED`.
- Persistent product-card write: `NONE`.
- Moderation submission: `NONE`.

