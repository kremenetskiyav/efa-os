# W04_UF001_CONTENT_PUBLISH_V1

| Field | Value |
| --- | --- |
| Project | EFA OS / OZON AI-Agents |
| SKU | ЭФА УФ 001Б |
| Ozon SKU | `4601821825` |
| Ozon product editor ID | `4861934525` |
| Source package | `W04_UF001_FINAL_CONTENT_PACKAGE_V2` |
| Fact source | `W02_UF001_APPLICABILITY_MASTER_RECONCILIATION_V1` |
| Execution time | `2026-09-12 17:43 MSK` |
| Mode | `OWNER-AUTHORIZED BOUNDED EXTERNAL WRITE` |
| Publication status | `SUBMITTED` |
| Moderation status | `ОБНОВЛЯЕТСЯ / RECALCULATION PENDING` |

## 1. Execution result

The owner confirmed the final action in the active Ozon Seller session. The
approved content package was submitted through `Отправить на модерацию` for
Ozon SKU `4601821825` only.

Immediate Seller-list read-back:

- product status: `Продается`;
- update status: `Обновляется`;
- the new title is already displayed in the seller product list;
- content rating: `Рассчитываем` in the product list;
- the editor predicts `65 -> 77.5` after moderation;
- media component remains `22.5 / 45`;
- description component is shown as `25 / 25` after moderation.

## 2. Exact fields changed

### Title

```text
Фильтр салонный угольный ЭФА УФ 001Б для Honda CR-V III (RE), CR-V IV (RM), OEM 80292-SLJ-013
```

### Description / annotation

Replaced the previous keyword-list description with the full V2 description.
The submitted version contains:

- TOP RUSSIA block;
- all 13 approved applicability groups;
- Accord IX Russia/import restrictions;
- Civic IX body/engine and year restrictions;
- Haval H2 engine/OEM/cassette restriction;
- Great Wall Hover H6 / Haval H6 I legacy-cassette restriction;
- `234 × 224 × 30 мм`;
- activated-carbon wording and the bounded claim `задерживает пыль`;
- the mandatory OEM/VIN safety line;
- canonical OEM `80292-SLJ-013` and one search-semantic occurrence of
  `80292SLJ013`, explicitly presented as the same number without hyphens.

### Structured characteristics

| Field | Before | Submitted value | Result |
| --- | --- | --- | --- |
| OEM-номер | `80292SLJ013` | `80292-SLJ-013` | `CHANGED / NORMALIZED` |
| Вид воздушного фильтра | Empty | `Угольный` | `CHANGED`; exact Seller enum confirmed |

### Rich-content

Added one native Ozon `raTextBlock` containing the six approved text sections:

1. Hero;
2. OEM;
3. Основные автомобили;
4. Проверка совместимости;
5. Размеры;
6. Активированный уголь.

No image, video or external asset was included in Rich-content.

## 3. Exact fields unchanged

| Field / scope | Read-back / reason |
| --- | --- |
| Артикул | `УФ 001Б` |
| Партномер | `УФ 001Б` |
| Dimensions | `234 × 224 × 30 мм` |
| Исполнение фильтра | `Фильтр из активированного угля` |
| Форма | `Прямоугольник` |
| Страна-изготовитель | `Россия` |
| Материал | Empty |
| Structured applicability | Existing 57 exact Seller rows left unchanged; no conditional group was flattened into a false unconditional row |
| Media | No image creation, upload, deletion, replacement or reordering; no video action |
| Seller-side displayed price | `953 ₽`, unchanged |
| Site price | `414 ₽` immediate list read-back; matches same-day protected-field baseline |
| Promotion | No edit; no active-promotion marker in the same-day baseline or immediate product row |
| CPC | No edit; same-day pre-content baseline: campaign `41279028` inactive |
| CPO | No edit; same-day pre-content baseline: `OFF`, status date `12.09.2026` |
| Elastic | No edit; same-day pre-content baseline: `OFF / NOT_SET` |
| Stock / FBO / FBS | No edit |
| Other SKU | No action |

Structured applicability was not expanded because the current Seller control
requires make/model/modification combinations and cannot preserve all textual
OEM/VIN, market, engine and cassette constraints as generation-level rows.
The exact 13-group applicability is preserved in the submitted description.

## 4. Content-rating read-back

| Component | Before | Seller prediction after moderation | Current state |
| --- | ---: | ---: | --- |
| Media | 22.5 / 45 | 22.5 / 45 | Unchanged |
| Characteristics | 30 / 30 | 30 / 30 | Unchanged |
| Description | 12.5 / 25 | 25 / 25 | Pending moderation |
| Overall | 65.0 | 77.5 | `Рассчитываем / pending` |

## 5. Commercial-settings integrity

The immediate product-list read-back showed site price `414 ₽` and no content
action touched price or promotion controls. The current CPC/CPO/Elastic
comparison baseline is the post-write read-back recorded earlier on the same
day in `W03_EFA_PORTFOLIO_PAID_EXPOSURE_PAUSE_EXECUTION_V1`:

- CPC `41279028`: `НЕАКТИВНА`;
- CPO: `OFF`;
- Elastic: `OFF / NOT_SET`;
- seller-side price: `953 ₽`;
- site price: `414 ₽`.

Result: `COMMERCIAL SETTINGS UNCHANGED`.

## 6. Linked and unexpected changes

- Unexpected linked changes: `NONE OBSERVED`.
- Ozon recalculation and moderation are expected asynchronous effects of the
  authorised content submission.

## 7. External writes performed

One bounded Ozon Seller moderation submission for SKU `4601821825`, containing:

1. title update;
2. description/annotation update;
3. OEM normalization;
4. `Вид воздушного фильтра = Угольный`;
5. text-only Rich-content JSON.

No other external writes were performed.
