# W04_UF005_SAFE_STRUCTURED_CLEANUP_AND_PUBLISH_V1

## Execution summary

| Field | Result |
| --- | --- |
| Date | 2026-09-12 (Europe/Moscow) |
| SKU | ЭФА УФ 005Б |
| Ozon SKU / editor ID | `4671328307 / 4861934542` |
| Publication status | `SUBMITTED`; active listing remains `Продаётся`, update status is `Обновляется` |
| Moderation status | `IN PROGRESS / Обновляется` |
| Rating status after submit | `Рассчитываем` |
| External write | One Owner-authorized content submission to Ozon for this SKU |

## Exact fields changed

1. **Title**

   `Фильтр салонный угольный ЭФА УФ 005Б для Citroen C4 I (LC/LA), Peugeot 308 I (T7), OEM 647975, 6479C2, 647941`

2. **Аннотация / Описание товара**

   Replaced with the exact FINAL DESCRIPTION from
   `W04_UF005_FINAL_CONTENT_PACKAGE_V2`. The submitted text contains all ten
   approved customer-facing families and preserves the model, engine, period,
   body and air-conditioning restrictions.

3. **Вид воздушного фильтра**

   `Угольный`

## Confirmed unchanged fields and scope

| Field | Read-back / execution evidence |
| --- | --- |
| OEM | `647975; 6479C2; 647941` |
| Article / part number | `УФ 005Б` |
| Dimensions | `178 × 285 × 30 мм` |
| Material | Empty |
| Shape | `Прямоугольник` |
| Country | `Россия` |
| Package | `Фильтр салона - 1 шт.` |
| Structured applicability | **25 rows retained**; no row deleted, corrected or added |
| Media | No media action performed |
| Rich-content | Not added or changed |
| Ceiling price | `943 ₽`; unchanged |
| Product-list price | `364 ₽` observed after submission; no price action performed |
| Preview promotion switches | All displayed switches remained off; no promotion action performed |
| CPC | No action performed; existing OFF state was not changed |
| CPO | No action performed; existing OFF state was not changed |
| Elastic | No action performed; existing OFF state was not changed |
| Stock / FBO / FBS | No action performed |
| Other SKU | No action performed |

## Applicability decision

The Owner explicitly declined deletion of the 18 structured rows. Therefore the
earlier proposed reduction from 25 rows to 7 was **not executed**.

- Structured rows before: **25**
- Structured rows after: **25**
- Removed exact count: **0**
- Full approved factual applicability preserved in description: **YES**

## Rating gate

Immediately before submission, Seller displayed the current-to-predicted
comparison as **56 → 68.5 after moderation**. After submission, the product list
showed the content rating as **`Рассчитываем`**. Final recalculated score is
therefore pending and must not yet be recorded as achieved.

## Post-submit read-back

- Final title: confirmed.
- Full description: confirmed.
- OEM: confirmed.
- Dimensions: confirmed.
- `Вид воздушного фильтра = Угольный`: confirmed.
- Material empty: confirmed.
- Structured applicability: 25 rows retained (`2` visible plus `Показать ещё 23`).
- Listing status: `Продаётся / Обновляется`.
- Rating: recalculation pending.
- Unexpected linked changes: none observed.

## External writes performed

One Ozon Seller submission for editor `4861934542`:

- title update;
- full description update;
- `Вид воздушного фильтра` set to `Угольный`;
- send to moderation.

No structured-applicability deletion and no commercial or media write was
performed.
